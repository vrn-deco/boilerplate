<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
import './App.scss'

export default {
  name: 'App',
  components: {},
  props: {},
  data() {
    return {}
  },
  computed: {},
  methods: {}
}
</script>
